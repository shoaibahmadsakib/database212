use university_190609
select * from instructor;
select COUNT(ID) as count_ID from instructor;
select MAX(salary) as max_salary from instructor;
select MIN(salary) as min_salary from instructor;
select AVG(salary) as avg_salary from instructor;



