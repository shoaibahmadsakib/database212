use university_190609
select dept_name from instructor;
select name from instructor where dept_name='ICE';